COLLABORATIVE MAPS

Note that these maps are a collaboration of 100' of hours by various people. This is an attempt to get multiple people to colaborate the same maps instead of having 15 different versions floating around. If you wish to update them, contact eerie or psylin.

Updated 1.25.22 by eerie to include: Fixed south seas in industrial, remapped Flanders, Remapped Mysterious island, added nile valley (Indust and ancient), added Rameses instance, added various automations like the new trans at nile valley.

Credit to Asix, Wrym, Psylin and Eerie for countless hours mapping thousands of rooms and maintaining it over the course of decades so you can type "walk stag"and not have to remember where you're going.

This is a two part package, the map itself, and the package that goes with it.

Place the map in your cmud/legendmud folder and load the package as normal.

