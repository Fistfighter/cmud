IMPORTANT FIRST STEPS:
config gmcplongpromptkeys(this should be ON)
Trigger your prompt (as the pattern) and be sure to click "trigger on prompt in the lower right hand corner.
In the command line box put:
#var gmcp {%gmcp.char.prompt}

This will put all available prompt options into a variable list that you can call on in scripts.
EXAMPLE #alias qq {#if (@gmcp.position="Standing") {jump} {stand}}
This would set it so when you type qq, if you're standing,  you'll jump, otherwise you'll stand.

NOTE that many of my scripts will utilize these variables. Please ignore this section if you've already done this.

HEALTH BARS:(
These will show a graphical bar of your targets health and will notate with % of health they are at. At the end of the bar your target's target will be noted. (If you're fighting A, and A is fighting B, it will show B)

Example:
You ravage Skoll, son of Fenrir with your pound!
You ravage Skoll, son of Fenrir with your hit!
You miss Skoll, son of Fenrir.
Wynn, the rune of healing, glows around your neck! You feel reinvigorated!
Skoll, son of Fenrir is leaking guts.
|+|+|23%|-|-|-|-|-|-|-| (you)
Skoll, son of Fenrir ravages you with his kick!
Skoll, son of Fenrir demolishes you with his crush!

Colors not shown