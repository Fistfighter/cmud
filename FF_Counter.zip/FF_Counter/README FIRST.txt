In Cmud, click settings, then click file/open.
Point to the package file downloaded and open it.

Everything should work out of the box.

NOTES: 
counterreport will display a report on everthing.
Counterreset will reset all data to 0.
If you enable your status window you will see real time tracking (there is a delay, it's not instant)
-You can enable the status window by clicking Window/status window
