Black - Essential runes (as decided by me)
Pink - Secondary, situational runes (as decided by me)
Blue - One time cast runes that don't need to be refreshed

Clicking any button will cast the rune, if the button is black or pink, the button will turn green and will automatically recast that rune when it falls off. Click the button again to stop recasting it.

Howevering over any button will give you the basic runelore info of what it does.

Merkstaave is not supported at this time.

The buttons are broken up into 3 sections, whichare the 3 Aetts.